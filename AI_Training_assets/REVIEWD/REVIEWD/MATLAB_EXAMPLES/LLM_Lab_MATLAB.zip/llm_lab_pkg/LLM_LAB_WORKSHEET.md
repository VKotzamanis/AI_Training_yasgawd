# LLM Lab — Worksheet

A two-parameter arithmetic problem, solved the way a language model solves it.
The model never computes. It predicts one token at a time from the tokens before it.

**Before each experiment, write your prediction down. Then run it.**
The exercise is worthless if you read the answer first.

---

## The model

Everything below runs the same four equations.

| | |
|---|---|
| logits | $\mathbf{z} = \mathbf{W}\mathbf{e} + \mathbf{b}$ |
| distribution | $P(v \mid \mathrm{ctx}) = \dfrac{e^{z_v}}{\sum_{j\in\mathcal{V}} e^{z_j}}$ |
| loss | $\mathcal{L}(\theta) = -\frac{1}{N}\sum_i \log P(y_i \mid \mathrm{ctx}_i)$ |
| residual | $\partial\mathcal{L}/\partial\mathbf{z} = \mathbf{P} - \mathbf{e}_y$ |

Decoding is greedy and autoregressive: emit $\arg\max_v P(v\mid\mathrm{ctx})$, append it to the
context, repeat. `DEPTH = 0` is the bare equation above; `DEPTH > 0` inserts tanh layers.

Set `RULE = '2x+1'`, `SPLIT = 'parity'`, `TOKENS = 'digit'`, `WIDTH = 32`, `DEPTH = 1`,
`NOISE = 0` unless an experiment says otherwise. Change **one** parameter at a time.

---

## E1 — Representation

Vary `TOKENS`. Everything else fixed.

> **Predict.** `'word'` gives the model one token per whole number. `'digit'` splits
> "34" into "3" and "4". Which generalises better, and by how much?

| TOKENS | \|θ\| | seen | held out |
|---|---|---|---|
| `word` | | | |
| `digit` | | | |

**Q1.1** Both reach 100% on prompts they saw. Why does only one work on prompts it didn't?

**Q1.2** The `word` model has roughly ten times more parameters. Why doesn't that help?

---

## E2 — Rule

Vary `RULE`. Everything else fixed.

> **Predict.** Rank these six from easiest to hardest **for you, by hand**, before running.
> Write the ranking down.

| RULE | seen | held out | most-significant digit | … | least-significant digit |
|---|---|---|---|---|---|
| `copy` | | | | | |
| `reverse` | | | | | |
| `2x+1` | | | | | |
| `x+7` | | | | | |
| `3x` | | | | | |
| `x^2` | | | | | |

**Q2.1** Compare your by-hand ranking to the model's. Where do they disagree most?

**Q2.2** Read the per-token columns. One token position is correct almost always.
Which, and why that one?

**Q2.3** The failures are concentrated in a single token position. What operation does that
position require that the others don't?

---

## E3 — Split

Vary `SPLIT`. Same rule, same model, same training.

- `random` — 80 prompts scattered across 1–99
- `range` — train on 1–69, test on 70–99
- `parity` — train where (tens + ones) is even, test where it is odd

| RULE | random | range | parity |
|---|---|---|---|
| `2x+1` | | | |
| `x+7` | | | |
| `3x` | | | |

**Q3.1** For `x+7`, two of these splits disagree by a wide margin. Which measurement would
you report in a paper, and how would you justify it?

**Q3.2** Under `random`, every digit 0–9 appears in both positions during training. Under
`parity` this is also true. So why do they give different answers?

**Q3.3** Under `range`, the input tens-digits 7, 8, 9 never appear in training. Is that a
fair test of the model, or a rigged one? Defend your answer.

---

## E4 — Scale

Set `RULE = 'x+7'`, `SPLIT = 'parity'`. Vary `WIDTH` and `DEPTH`.
`WIDTH` is units per layer. `DEPTH` is the number of layers. They are not the same knob.

| held out [%] | DEPTH 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| WIDTH 8 | | | | |
| WIDTH 32 | | | | |
| WIDTH 128 | | | | |

Then, at `WIDTH = 32`, `DEPTH = 1`, set `ITER` to 8000, 40000, 120000.

| ITER | held out |
|---|---|
| 8000 | |
| 40000 | |
| 120000 | |

**Q4.1** Which buys more accuracy per parameter, width or depth? Compute the ratio.

**Q4.2** Neither axis reaches a usable accuracy. What does that rule out as the cause of
the failure in E2?

**Q4.3** The entire `DEPTH 0` column is identical across all three widths. This is not a
bug. Explain it from the definition of `WIDTH`.

**Q4.4** Repeat one cell of the table with `RULE = '2x+1'`. The whole table is flat at 100%.
What does an architecture-insensitive result tell you about what is binding?

---

## E5 — Corpus reliability

Vary `NOISE`, the fraction of training pairs whose answer violates the rule.

| NOISE | seen | held out | final L(θ) |
|---|---|---|---|
| 0.00 | | | |
| 0.05 | | | |
| 0.10 | | | |
| 0.20 | | | |
| 0.40 | | | |

**Q5.1** At `NOISE = 0.20`, accuracy on the **training** prompts is below 100%. The model
saw those exact pairs. Why can't it reproduce them?

**Q5.2** Accuracy on training prompts and held-out prompts converge as noise rises.
What does that say about what the model extracted from the corpus?

**Q5.3** $\mathcal{L}(\theta)$ reaches roughly the same near-zero value at every noise
level, including `NOISE = 0.40`. The model drives training loss to zero on a corpus that
contradicts the rule 40% of the time. What does this tell you about using training loss as
evidence that a model is correct?

---

## Synthesis

**S1** A model answers 200 questions correctly and you conclude it understands the task.
List three things from E1–E5 that could produce that result without any understanding.

**S2** You are asked whether a trained model has learned a physical law or memorised your
dataset. Describe the test you would run, and what result would settle it.

**S3** In E2 the model was better at a task you find hard and worse at a task you find
trivial. Explain the mismatch in terms of the representation, not the difficulty.

**S4** Everything here has two input tokens and at most four output tokens. Name one
conclusion from this lab that you expect to survive at 10¹¹ parameters, and one you expect
to break. Justify both.
