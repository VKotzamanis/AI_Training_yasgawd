%% LLM_TOY_DEMO2  Why the lookup model failed, and what actually fixes it
%
%   Part 1 proves the bigram model of LLM_TOY_DEMO reached its GLOBAL optimum.
%           Training was not the problem. The architecture was.
%
%   Part 2 changes one thing -- how the prompt is TOKENISED -- and the same
%           machinery starts answering questions it was never trained on.
%
%   Part 3 shows the errors that remain. They are carry errors, which is the
%           documented failure mode of real LLMs on arithmetic.
%
%   Base MATLAB only. No toolboxes. Runs in GNU Octave.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
UHcrimson = [156 28 36]/255;
teal      = [15  77 89]/255;

%% ==================================================================
%  PART 1.  TRAINING IS NOT THE BOTTLENECK
%  ==================================================================
%  For softmax + cross-entropy with logits linear in theta, the loss is
%  CONVEX: one minimum, no local traps. And for the bigram model the
%  minimiser is known in closed form:
%
%        P*(y | x)  =  C(y,x) / n_x        (the empirical frequency table)
%
%  So we can check gradient descent against the exact answer.

NMAX  = 61;
vocab = [arrayfun(@(k) sprintf('%d',k), 1:NMAX, 'UniformOutput', false), {'London'}];
V     = numel(vocab);
tid   = containers.Map(vocab, 1:V);

C = zeros(V,V);
for x = 1:20
    C(tid(sprintf('%d',2*x+1)), tid(sprintf('%d',x))) = 45;
    C(tid(sprintf('%d',2*x+3)), tid(sprintf('%d',x))) =  3;
    C(tid(sprintf('%d',2*x-1)), tid(sprintf('%d',x))) =  2;
end
C(tid('2'), tid('London')) = 50;
N = sum(C(:));  nx = sum(C,1);

W = zeros(V,V); b = zeros(V,1);
for t = 1:6000
    Z = W + b;  Zs = Z - max(Z,[],1);  E = exp(Zs);  P = E ./ sum(E,1);
    G = (P .* nx - C)/N;
    W = W - 5*G;  b = b - 5*sum(G,2);
end
Z = W + b; Zs = Z - max(Z,[],1); E = exp(Zs); P = E ./ sum(E,1);
L_gd = -sum(sum(C .* log(P + realmin)))/N;

seen  = nx > 0;
Pstar = zeros(V,V);
Pstar(:,seen) = C(:,seen) ./ nx(seen);
L_opt = -sum(sum(C(:,seen) .* log(Pstar(:,seen) + realmin)))/N;

fprintf('=== PART 1: was the training the problem? ===\n');
fprintf('  gradient descent, 6000 steps : L = %.6f\n', L_gd);
fprintf('  closed-form GLOBAL minimum   : L = %.6f\n', L_opt);
fprintf('  gap                          :     %.2e\n', L_gd - L_opt);
fprintf('  The optimiser is already there. More epochs, a better learning\n');
fprintf('  rate, Adam, more data -- none of it can help. A lookup table has\n');
fprintf('  no parameter connecting prompt "27" to anything it ever saw.\n\n');

%% ==================================================================
%  PART 2.  CHANGE THE TOKENISATION, NOT THE TRAINING
%  ==================================================================
%  Old encoding: "27" is ONE atomic token with its own private column of W.
%                Never seen -> never updated -> no possible answer.
%
%  New encoding: "27" is TWO digit tokens, "2" and "7". Both appear all over
%                the corpus. Now there IS a gradient path to an unseen input.
%                This is what real tokenisers do (BPE / digit splitting).
%
%  Task   : x -> y = 2x+1,  x = 1..99
%  Input  : 2 digit tokens, one-hot(10) each        -> 20 dims
%  Output : 3 digit heads (hundreds, tens, ones)    -> 3 softmaxes over {0..9}
%  Split  : 80 values of x for training, 19 HELD OUT and never seen.

rng(7);
allx = 1:99;
perm = randperm(99);
XTR  = sort(perm(1:80));
XTE  = sort(perm(81:99));

[Atr, Ttr] = build_data(XTR);
[Ate, Tte] = build_data(XTE);

fprintf('=== PART 2: same loss, same optimiser, different tokenisation ===\n');
fprintf('  train on %d values of x, hold out %d\n', numel(XTR), numel(XTE));
fprintf('  held-out x: %s\n\n', mat2str(XTE));

archs  = [0 8 32 128];          % 0 = no hidden layer
names  = {'lookup (Part 1)','digit + linear','digit + d=8','digit + d=32','digit + d=128'};
accTR  = zeros(1,5);  accTE = zeros(1,5);  npar = zeros(1,5);

accTR(1) = 100;  accTE(1) = 0;  npar(1) = V*V + V;    % the Part 1 model, for reference

for k = 1:4
    [pr, np_] = train_digit(Atr, Ttr, archs(k), 20000, 0.5);
    accTR(k+1) = 100*mean(pr(Atr) == 2*XTR(:)+1);
    accTE(k+1) = 100*mean(pr(Ate) == 2*XTE(:)+1);
    npar(k+1)  = np_;
    fprintf('  %-16s |theta| = %-6d  train = %5.1f%%   HELD-OUT = %5.1f%%\n', ...
            names{k+1}, np_, accTR(k+1), accTE(k+1));
end
fprintf('\n  The lookup model scores 0%% on held-out prompts and CANNOT do better.\n');
fprintf('  Splitting the prompt into reusable tokens is what buys generalisation.\n');
fprintf('  Note d=128 does worse than d=32: past a point, capacity overfits.\n\n');

%% ==================================================================
%  PART 3.  THE ERRORS THAT SURVIVE
%  ==================================================================
[pr32, ~] = train_digit(Atr, Ttr, 32, 20000, 0.5);
[pr0,  ~] = train_digit(Atr, Ttr,  0, 20000, 0.5);
yhat = pr0(Ate);  ytrue = 2*XTE(:)+1;
bad  = find(yhat ~= ytrue);

fprintf('=== PART 3: what the digit model still gets wrong (linear case) ===\n');
if isempty(bad)
    fprintf('  no held-out errors\n');
else
    for j = bad(:)'
        fprintf('  x = %-3d  predicted %-4d  true %-4d   off by %+d\n', ...
                XTE(j), yhat(j), ytrue(j), yhat(j)-ytrue(j));
    end
    fprintf('\n  Every error is off by exactly 10: a failed CARRY from the ones\n');
    fprintf('  digit into the tens digit. The model learned the digit patterns\n');
    fprintf('  it saw most often, not the carry rule. This is precisely how\n');
    fprintf('  production LLMs fail on arithmetic -- and why they call a tool.\n');
end

%% ------------------------------------------------------------------
%  FIGURES
%  ------------------------------------------------------------------
figure('Color','w','Position',[80 80 760 420]);
Bd = [accTR; accTE]';
h = bar(Bd, 'grouped'); hold on;
set(h(1),'FaceColor',teal,'EdgeColor','none');
set(h(2),'FaceColor',UHcrimson,'EdgeColor','none');
set(gca,'XTick',1:5,'XTickLabel',names,'XTickLabelRotation',20);
ylabel('exact-match accuracy  (%)'); ylim([0 112]);
legend({'prompts seen in training','prompts NEVER seen'}, 'Location','south');
title('Memorisation is free. Generalisation comes from tokenisation.');
grid on; box on;
for k = 1:5
    text(k+0.16, accTE(k)+5, sprintf('%.0f%%',accTE(k)), ...
        'HorizontalAlignment','center','Color',UHcrimson,'FontSize',11);
end

figure('Color','w','Position',[80 540 760 380]);
plot(XTE, ytrue, 'o-', 'Color', teal, 'LineWidth', 1.6, ...
     'MarkerFaceColor', teal, 'MarkerSize', 5); hold on;
plot(XTE, yhat, 'x', 'Color', UHcrimson, 'LineWidth', 2, 'MarkerSize', 11);
xlabel('held-out prompt  x'); ylabel('completion  y');
legend({'true 2x+1','model prediction'}, 'Location','northwest');
title('Held-out predictions: near-perfect, with isolated carry failures');
grid on; box on;

%% ==================================================================
%  LOCAL FUNCTIONS
%  ==================================================================

function [A, T] = build_data(xs)
%BUILD_DATA Encode x as two digit one-hots; encode y = 2x+1 as three digits.
    xs = xs(:);  n = numel(xs);
    A = zeros(n, 20);
    A(sub2ind([n 20], (1:n)', floor(xs/10) + 1))      = 1;   % tens digit of x
    A(sub2ind([n 20], (1:n)', mod(xs,10)  + 11))      = 1;   % ones digit of x
    y = 2*xs + 1;
    T = [floor(y/100), mod(floor(y/10),10), mod(y,10)];      % n x 3, digits 0..9
end

function P = softmax_heads(Z)
%SOFTMAX_HEADS Independent softmax over each 10-column digit head.
    P = zeros(size(Z));
    for k = 1:3
        c  = (k-1)*10 + (1:10);
        Zk = Z(:,c) - max(Z(:,c),[],2);
        E  = exp(Zk);
        P(:,c) = E ./ sum(E,2);
    end
end

function [predfun, npar] = train_digit(A, T, hidden, ITER, eta)
%TRAIN_DIGIT Train the digit model. hidden = 0 gives no hidden layer.
    rng(0);
    n = size(A,1);
    rows = (1:n)';
    if hidden > 0
        W1 = 0.5*randn(20,hidden);  b1 = zeros(1,hidden);
        W2 = 0.5*randn(hidden,30);  b2 = zeros(1,30);
        npar = 20*hidden + hidden + hidden*30 + 30;
    else
        W2 = 0.1*randn(20,30);      b2 = zeros(1,30);
        npar = 20*30 + 30;
    end
    for t = 1:ITER
        if hidden > 0
            H = tanh(A*W1 + b1);  Z = H*W2 + b2;
        else
            Z = A*W2 + b2;
        end
        P = softmax_heads(Z);
        G = P;
        for k = 1:3                                   % subtract the one-hot target
            idx = sub2ind([n 30], rows, (k-1)*10 + T(:,k) + 1);
            G(idx) = G(idx) - 1;
        end
        G = G/n;
        if hidden > 0
            dW2 = H'*G;  db2 = sum(G,1);
            dH  = (G*W2') .* (1 - H.^2);
            W1  = W1 - eta*(A'*dH);   b1 = b1 - eta*sum(dH,1);
            W2  = W2 - eta*dW2;       b2 = b2 - eta*db2;
        else
            W2 = W2 - eta*(A'*G);     b2 = b2 - eta*sum(G,1);
        end
    end
    predfun = @(Aq) decode(Aq);
    function y = decode(Aq)
        if hidden > 0, Zq = tanh(Aq*W1 + b1)*W2 + b2; else, Zq = Aq*W2 + b2; end
        d = zeros(size(Aq,1),3);
        for k = 1:3
            [~, im] = max(Zq(:, (k-1)*10 + (1:10)), [], 2);
            d(:,k) = im - 1;
        end
        y = d(:,1)*100 + d(:,2)*10 + d(:,3);
    end
end
