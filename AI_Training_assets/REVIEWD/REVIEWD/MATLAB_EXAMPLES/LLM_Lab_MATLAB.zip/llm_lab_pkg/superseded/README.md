# Superseded drafts — do not use in the lecture

These predate the autoregressive rebuild. **Their numbers are stale** and differ from the
handout (e.g. 2x+1 on the range split moved from ~1% to 80% after the rebuild).

They are kept for two things only:

- `llm_toy_demo.m` — the closed-form convexity proof (gradient descent vs the analytic
  global minimum), and a corpus with **stochastic** noise that produces a genuine entropy
  floor: H(y|x) = 0.3737, reached to 0.3755. The current lab uses deterministic noise and
  therefore has no floor.
- `llm_toy_demo2.m`, `llm_live_demo.m` — earlier parallel-head versions. Superseded entirely.

Everything else lives in the parent folder.
