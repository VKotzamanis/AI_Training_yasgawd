%% LLM_TOY_DEMO  A minimal but genuine language model trained on arithmetic
%
%   Demonstrates that a language model does not compute y = 2x+1. It stores a
%   conditional probability table over a discrete vocabulary and reports the
%   most frequent continuation it saw during training.
%
%   Mechanism is identical to a transformer's output stage:
%       one-hot token -> logits -> softmax -> categorical distribution
%       trained by cross-entropy (negative log-likelihood)
%
%   Base MATLAB only. No toolboxes. Also runs in GNU Octave.
%
%   Figures
%     1  Training loss vs. iteration, with ln(V) ceiling and entropy floor
%     2  Cross-entropy loss surface over two logits (the "bowl", done correctly)
%     3  P(y | x = "3")       -- what the model actually outputs
%     4  P(y | x = "27")      -- an unseen prompt; the failure mode
%     5  Capacity sweep: final loss vs. hidden dimension d
%
%   D. <author>, University of Houston.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
UHcrimson = [156 28 36]/255;
teal      = [15  77 89]/255;
grey      = [160 160 160]/255;

%% ------------------------------------------------------------------
%  1. VOCABULARY  V
%  ------------------------------------------------------------------
%  Tokens are SYMBOLS, not numbers. "7" is token #7 in a list; the model
%  never performs arithmetic on it. "London" is stored exactly the same way.

NMAX  = 61;
vocab = [arrayfun(@(k) sprintf('%d',k), 1:NMAX, 'UniformOutput', false), {'London'}];
V     = numel(vocab);                       % V = 62
tid   = containers.Map(vocab, 1:V);         % token string -> row index

fprintf('Vocabulary size |V| = %d\n', V);

%% ------------------------------------------------------------------
%  2. CORPUS  D  (prompt token -> completion token)
%  ------------------------------------------------------------------
%  50 occurrences of each prompt x = 1..20, deliberately NOT noise-free:
%     45 x  (x -> 2x+1)     the "rule"
%      3 x  (x -> 2x+3)     corpus noise
%      2 x  (x -> 2x-1)     corpus noise
%  plus 50 x ("London" -> "2"), which the same machinery handles unchanged.
%
%  Prompts 21..61 NEVER APPEAR. They are the held-out test.

XTRAIN = 1:20;
C = zeros(V,V);                             % C(y,x) = count of pair (x -> y)
for x = XTRAIN
    C(tid(sprintf('%d',2*x+1)), tid(sprintf('%d',x))) = 45;
    C(tid(sprintf('%d',2*x+3)), tid(sprintf('%d',x))) =  3;
    C(tid(sprintf('%d',2*x-1)), tid(sprintf('%d',x))) =  2;
end
C(tid('2'), tid('London')) = 50;

N  = sum(C(:));                             % corpus size
nx = sum(C,1);                              % 1 x V, occurrences of each prompt
fprintf('Corpus size N = %d over %d distinct prompts\n', N, sum(nx>0));

% Irreducible loss: the conditional entropy of the corpus itself.
p    = [0.90 0.06 0.04];
Hnum = -sum(p.*log(p));
Lfloor = (1000*Hnum + 50*0)/N;
fprintf('Theoretical loss floor  H(y|x) = %.4f nats\n', Lfloor);
fprintf('Uniform-guess loss      ln(V)  = %.4f nats\n\n', log(V));

%% ------------------------------------------------------------------
%  3. MODEL A: the parameters theta = {W, b}
%  ------------------------------------------------------------------
%  Forward pass for prompt token x, one-hot encoded as e_x:
%       z = W*e_x + b        (picks out column x of W, adds bias)
%       P(y = v | x) = exp(z_v) / sum_j exp(z_j)
%
%  Because e_x is one-hot, W*e_x is just W(:,x). Every prompt column is
%  independent -- which is precisely why this model cannot generalise.

W = zeros(V,V);
b = zeros(V,1);

eta  = 5.0;                                 % learning rate
ITER = 6000;
Lhist = zeros(ITER,1);

for t = 1:ITER
    Z = W + b;                              % V x V, column x holds logits for x
    P = softmax_cols(Z);
    Lhist(t) = -sum(sum(C .* log(P + realmin)))/N;

    % Cross-entropy gradient. For one sample, dL/dz = P - e_y.
    % Aggregated over the corpus, weighted by prompt counts:
    G = (P .* nx - C)/N;                    % V x V
    W = W - eta*G;
    b = b - eta*sum(G,2);
end

Z = W + b;  P = softmax_cols(Z);
Lfinal = -sum(sum(C .* log(P + realmin)))/N;
fprintf('--- Model A: bigram lookup, |theta| = %d ---\n', V*V + V);
fprintf('L(0)      = %.4f   (= ln(V), the model knows nothing)\n', Lhist(1));
fprintf('L(final)  = %.4f   (floor = %.4f)\n\n', Lfinal, Lfloor);

%% ------------------------------------------------------------------
%  4. WHAT THE TRAINED MODEL IS
%  ------------------------------------------------------------------
%  Claim: at the optimum, P(y|x) equals the empirical frequency C(y,x)/n_x.
%  This is provable for this architecture, and it is the whole lesson.

show_dist(P, vocab, tid, '3',      3);
show_dist(P, vocab, tid, 'London', 3);

i3 = tid('3'); i7 = tid('7');
fprintf('  empirical  C(7,3)/n_3 = %.4f\n', C(i7,i3)/nx(i3));
fprintf('  model      P(7 | 3)   = %.4f   <-- the model IS the frequency table\n\n', P(i7,i3));

%% ------------------------------------------------------------------
%  5. THE UNSEEN PROMPT  (this is the point of the lecture)
%  ------------------------------------------------------------------
xq   = 27;  qs = sprintf('%d',xq);  ys = sprintf('%d',2*xq+1);
pq   = P(:,tid(qs));
Hq   = -sum(pq.*log(pq + realmin));

fprintf('--- Held-out prompt x = "%s"  (rule says y = "%s") ---\n', qs, ys);
show_dist(P, vocab, tid, qs, 3);
fprintf('  P("%s" | "%s")  = %.5f\n', ys, qs, pq(tid(ys)));
fprintf('  entropy         = %.4f nats  (uniform = %.4f)\n', Hq, log(V));
fprintf('  The model falls back to the marginal. It never learned a rule,\n');
fprintf('  so there is nothing to extrapolate. A human answers instantly.\n\n');

%% ------------------------------------------------------------------
%  6. MODEL B: capacity sweep  (why real models are large)
%  ------------------------------------------------------------------
%  Insert a d-dimensional bottleneck:  e_x -> E (V x d) -> U (d x V) -> logits.
%  |theta| = 2*V*d + V.  Sweep d and watch the loss fall to the entropy floor.

dlist = [1 2 4 8 16];
Lsweep = zeros(size(dlist));
fprintf('--- Model B: hidden dimension sweep ---\n');
for k = 1:numel(dlist)
    Lsweep(k) = train_bottleneck(C, nx, N, V, dlist(k), 5.0, 8000);
    fprintf('  d = %-3d  |theta| = %-5d  L = %.4f\n', ...
            dlist(k), 2*V*dlist(k)+V, Lsweep(k));
end
fprintf('  d=1 cannot represent the mapping. d>=4 saturates at the floor:\n');
fprintf('  extra parameters buy nothing once the corpus noise dominates.\n');

%% ==================================================================
%  FIGURES
%  ==================================================================

% --- Fig 1: training curve -----------------------------------------
figure('Color','w','Position',[80 80 560 400]);
semilogx(1:ITER, Lhist, '-', 'Color', teal, 'LineWidth', 2); hold on;
plot([1 ITER], [log(V) log(V)], '--', 'Color', grey,      'LineWidth', 1.4);
plot([1 ITER], [Lfloor Lfloor], '--', 'Color', UHcrimson, 'LineWidth', 1.4);
text(2, log(V)-0.18, 'ln(V): knows nothing', 'Color', grey, 'FontSize', 11);
text(2, Lfloor+0.18, 'H(y|x): corpus noise floor', 'Color', UHcrimson, 'FontSize', 11);
xlabel('gradient step  t'); ylabel('cross-entropy  L(\theta)  [nats]');
title('Training: L(\theta) = -\Sigma log P(y_i | x_i; \theta)');
grid on; box on; ylim([0 4.4]);

% --- Fig 2: the loss bowl, done with the correct loss ---------------
%  Freeze theta*, then sweep two logits for prompt "3" and recompute L.
d1 = linspace(-4,4,60);  d2 = linspace(-4,4,60);
[D1,D2] = meshgrid(d1,d2);
Lsurf = zeros(size(D1));
i9 = tid('9');
for a = 1:numel(D1)
    Wp = W;
    Wp(i7,i3) = W(i7,i3) + D1(a);
    Wp(i9,i3) = W(i9,i3) + D2(a);
    Pp = softmax_cols(Wp + b);
    Lsurf(a) = -sum(sum(C .* log(Pp + realmin)))/N;
end
figure('Color','w','Position',[660 80 560 400]);
contourf(D1, D2, Lsurf, 25, 'LineColor','none'); colorbar;
hold on; plot(0,0,'o','MarkerFaceColor',UHcrimson,'MarkerEdgeColor','k','MarkerSize',9);
xlabel('\Delta z("7" | "3")'); ylabel('\Delta z("9" | "3")');
title('Cross-entropy is convex in the logits: one minimum, \theta^*');
box on;

% --- Fig 3: what the model outputs for a seen prompt ----------------
bar_dist(P(:,i3), vocab, UHcrimson, teal, 'P(y | x = "3")   -- 45/50 of the corpus said "7"');

% --- Fig 4: the unseen prompt ---------------------------------------
bar_dist(pq, vocab, UHcrimson, teal, ...
    sprintf('P(y | x = "%s")   -- never trained; correct answer "%s" gets %.4f', qs, ys, pq(tid(ys))));

% --- Fig 5: capacity sweep ------------------------------------------
figure('Color','w','Position',[660 540 560 380]);
semilogx(dlist, Lsweep, 'o-', 'Color', teal, 'LineWidth', 2, ...
    'MarkerFaceColor', teal, 'MarkerSize', 7); hold on;
plot([min(dlist) max(dlist)], [Lfloor Lfloor], '--', 'Color', UHcrimson, 'LineWidth', 1.4);
text(1.2, Lfloor+0.10, 'irreducible loss H(y|x)', 'Color', UHcrimson, 'FontSize', 11);
xlabel('hidden dimension  d   (|\theta| = 2Vd + V)');
ylabel('converged loss  L(\theta^*)  [nats]');
title('Capacity: parameters buy accuracy only until noise dominates');
grid on; box on; set(gca,'XTick',dlist);

%% ==================================================================
%  LOCAL FUNCTIONS
%  ==================================================================

function P = softmax_cols(Z)
%SOFTMAX_COLS Column-wise softmax, shifted for numerical stability.
    Z = Z - max(Z,[],1);
    E = exp(Z);
    P = E ./ sum(E,1);
end

function show_dist(P, vocab, tid, q, topk)
%SHOW_DIST Print the top-k most probable completions for prompt token q.
    p = P(:, tid(q));
    [ps, ord] = sort(p, 'descend');
    fprintf('  prompt "%s"  ->  ', q);
    for k = 1:topk
        fprintf('%s:%.4f  ', vocab{ord(k)}, ps(k));
    end
    fprintf('\n');
end

function bar_dist(p, vocab, cHi, cLo, ttl)
%BAR_DIST Plot the full categorical distribution over the vocabulary.
    figure('Color','w','Position',[80 540 900 380]);
    [~, imax] = max(p);
    bar(1:numel(p), p, 'FaceColor', cLo, 'EdgeColor','none'); hold on;
    bar(imax, p(imax), 'FaceColor', cHi, 'EdgeColor','none');
    set(gca,'XTick', 1:2:numel(p), 'XTickLabel', vocab(1:2:end), 'XTickLabelRotation', 90);
    xlabel('token  v \in V'); ylabel('P(y = v | x; \theta^*)');
    title(ttl); xlim([0 numel(p)+1]); grid on; box on;
end

function L = train_bottleneck(C, nx, N, V, d, eta, ITER)
%TRAIN_BOTTLENECK Train e_x -> E -> U -> logits and return converged loss.
%   Non-convex in {E,U}, so the result depends mildly on initialisation.
    rng(1);
    E = 0.1*randn(V,d);
    U = 0.1*randn(d,V);
    c = zeros(V,1);
    for t = 1:ITER
        H = E.';                            % d x V, hidden state per prompt
        Z = U.'*H + c;
        Zs = Z - max(Z,[],1); Ex = exp(Zs); P = Ex ./ sum(Ex,1);
        G  = (P .* nx - C)/N;
        dU = H*G.';
        dH = U*G;
        U = U - eta*dU;
        E = E - eta*dH.';
        c = c - eta*sum(G,2);
    end
    H = E.'; Z = U.'*H + c;
    Zs = Z - max(Z,[],1); Ex = exp(Zs); P = Ex ./ sum(Ex,1);
    L = -sum(sum(C .* log(P + realmin)))/N;
end
