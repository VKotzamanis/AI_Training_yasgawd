%% LLM_LIVE_DEMO  Type a number. Watch two models answer it.
%
%   Run this in front of the class. It does three things:
%
%     1. Trains a digit-tokenised model with the figure updating live, so the
%        audience watches a held-out prediction snap into place.
%     2. Drops into a prompt loop. You type x; both models answer.
%     3. Shows the probability distribution behind every answer, so nobody
%        thinks the model "computed" anything.
%
%   Model L  single-token lookup       -> memorises, cannot generalise
%   Model D  digit tokens + hidden layer -> generalises, fails on carries
%
%   Base MATLAB only. No toolboxes. Runs in GNU Octave.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
crimson = [156 28 36]/255;
teal    = [15  77 89]/255;
grey    = [170 170 170]/255;

%% ---------------- data split -------------------------------------
%  THIS SWITCH IS THE LECTURE.
%
%   'random'  scatter 19 held-out values across 1..99.  Every digit 0-9 still
%             appears in training, so the model only has to INTERPOLATE.
%             Result: ~100% held-out. Looks like it learned arithmetic.
%
%   'carry'   train ONLY on x whose ones digit is < 5, i.e. cases where 2x+1
%             needs no carry. Test on the carry cases. The model has seen
%             every digit, just never in a carry.
%             Result: ~0% held-out. It did not learn arithmetic.
%
%   Run 'random' first, let the room conclude the model can do maths,
%   then re-run with 'carry'. Same model, same optimiser, same loss.

SPLIT = 'carry';        % <-- 'random' | 'range' | 'carry'

rng(7);
switch SPLIT
    case 'random'
        pm  = randperm(99);
        XTR = sort(pm(1:80));  XTE = sort(pm(81:99));
    case 'range'
        XTR = 1:69;            XTE = 70:99;
    case 'carry'
        allx = 1:99;
        XTR  = allx(mod(allx,10) <  5);
        XTE  = allx(mod(allx,10) >= 5);
    otherwise
        error('SPLIT must be random, range or carry');
end
isTR = false(1,99); isTR(XTR) = true;

fprintf('Split mode : %s\n', SPLIT);
fprintf('Training on %d values of x, holding out %d.\n', numel(XTR), numel(XTE));
fprintf('Held out: %s\n\n', mat2str(XTE));

%% ---------------- Model L: single-token lookup --------------------
%  Analytic optimum (proved in LLM_TOY_DEMO2): for a seen prompt the model
%  returns its memorised answer; for an unseen prompt it returns the corpus
%  marginal, because that column of W never received a gradient.
VL     = 199;
margL  = zeros(VL,1);
for x = XTR, margL(2*x+1) = margL(2*x+1) + 1; end
margL  = margL / sum(margL);

%% ---------------- Model D: digit tokenisation ---------------------
[Atr, Ttr] = build_data(XTR);
hidden = 32;  eta = 0.5;  ITER = 20000;

rng(0);
W1 = 0.5*randn(20,hidden);  b1 = zeros(1,hidden);
W2 = 0.5*randn(hidden,30);  b2 = zeros(1,30);

probe  = XTE(1);                              % a held-out prompt to watch
[Ap,~] = build_data(probe);
ptrue  = 2*probe + 1;

f = figure('Color','w','Position',[60 80 1000 620]);
axL = subplot(2,1,1);
hL  = plot(axL, nan, nan, '-', 'Color', teal, 'LineWidth', 2);
xlabel(axL,'gradient step'); ylabel(axL,'cross-entropy  L(\theta)');
set(axL,'XScale','log'); grid(axL,'on'); box(axL,'on');
xlim(axL,[1 ITER]); ylim(axL,[0 10.5]);

hB = gobjects(1,3); ttl = {'hundreds','tens','ones'};
for k = 1:3
    ax = subplot(2,3,3+k);
    hB(k) = bar(ax, 0:9, zeros(1,10), 'FaceColor', teal, 'EdgeColor','none');
    ylim(ax,[0 1]); xlim(ax,[-0.6 9.6]); grid(ax,'on'); box(ax,'on');
    title(ax, sprintf('P(%s digit)', ttl{k}));
    xlabel(ax,'digit'); if k==1, ylabel(ax,'probability'); end
end
sg = sgtitle(sprintf('Training... probe x = %d (never seen), true answer %d', probe, ptrue));
set(sg,'FontName','Times New Roman');

Lh = nan(1,ITER);  n = numel(XTR);  rows = (1:n)';
for t = 1:ITER
    H = tanh(Atr*W1 + b1);  Z = H*W2 + b2;
    P = softmax_heads(Z);

    L = 0;
    for k = 1:3
        idx = sub2ind([n 30], rows, (k-1)*10 + Ttr(:,k) + 1);
        L = L - sum(log(P(idx) + realmin));
    end
    Lh(t) = L/n;

    G = P;
    for k = 1:3
        idx = sub2ind([n 30], rows, (k-1)*10 + Ttr(:,k) + 1);
        G(idx) = G(idx) - 1;
    end
    G = G/n;
    dW2 = H'*G;  db2 = sum(G,1);
    dH  = (G*W2') .* (1 - H.^2);
    W1 = W1 - eta*(Atr'*dH);  b1 = b1 - eta*sum(dH,1);
    W2 = W2 - eta*dW2;        b2 = b2 - eta*db2;

    upd = 10; if t > 500, upd = 250; end
    if mod(t,upd) == 0 || t == 1
        Pp = softmax_heads(tanh(Ap*W1 + b1)*W2 + b2);
        set(hL, 'XData', 1:t, 'YData', Lh(1:t));
        d = zeros(1,3);
        for k = 1:3
            pk = Pp((k-1)*10 + (1:10));
            set(hB(k), 'YData', pk);
            [~, im] = max(pk);  d(k) = im - 1;
        end
        yh = d(1)*100 + d(2)*10 + d(3);
        mark = 'WRONG';  if yh == ptrue, mark = 'CORRECT'; end
        set(sg,'String', sprintf('step %d   |   probe x = %d (never seen)   |   model says %d, truth %d   [%s]', ...
            t, probe, yh, ptrue, mark));
        drawnow limitrate;
    end
end
fprintf('Training complete.  final L = %.4f\n\n', Lh(end));

%% ---------------- accuracy summary --------------------------------
yhTR = predict_D(build_data(XTR), W1,b1,W2,b2);
yhTE = predict_D(build_data(XTE), W1,b1,W2,b2);
aTR = 100*mean(yhTR == (2*XTR(:)+1));
aTE = 100*mean(yhTE == (2*XTE(:)+1));
fprintf('Model D   seen prompts     : %5.1f%%\n', aTR);
fprintf('Model D   HELD-OUT prompts : %5.1f%%\n', aTE);
fprintf('Model L   HELD-OUT prompts :   0.0%%  (structurally impossible)\n');
if strcmp(SPLIT,'random')
    fprintf('\n  A random split only tests INTERPOLATION. Every digit 0-9 appears\n');
    fprintf('  in training, so high accuracy here is not evidence of a learned rule.\n');
    fprintf('  Re-run with SPLIT = ''carry''.\n\n');
else
    fprintf('\n  Hold out a STRUCTURED region and the same model collapses.\n');
    fprintf('  It memorised digit patterns, not the carry rule.\n\n');
end

%% ---------------- interactive prompt loop --------------------------
figure('Color','w','Position',[60 80 1000 420]);
fprintf('---------------------------------------------------------------\n');
fprintf(' Type a value of x between 1 and 99.  Enter 0 to stop.\n');
fprintf(' Try one the model saw, then one it did not.\n');
fprintf('---------------------------------------------------------------\n');

while true
    xq = input('  prompt  x = ');
    if isempty(xq) || xq == 0, break; end
    if xq < 1 || xq > 99 || xq ~= fix(xq)
        fprintf('  x must be a whole number in 1..99\n'); continue;
    end

    ytrue  = 2*xq + 1;
    [Aq,~] = build_data(xq);
    Pq = softmax_heads(tanh(Aq*W1 + b1)*W2 + b2);
    d  = zeros(1,3); conf = zeros(1,3);
    for k = 1:3
        pk = Pq((k-1)*10 + (1:10));
        [conf(k), im] = max(pk);  d(k) = im - 1;
    end
    yD = d(1)*100 + d(2)*10 + d(3);

    if isTR(xq)
        seenTxt = 'SEEN in training';
        yL = ytrue;  pL = 1.0;
    else
        seenTxt = 'NEVER SEEN';
        [pL, yL] = max(margL);        % lookup model falls back to the marginal
    end

    fprintf('\n  x = %d   (%s)   true answer %d\n', xq, seenTxt, ytrue);
    fprintf('    Model L (lookup) : %-4d   p = %.4f   %s\n', yL, pL, verdict(yL,ytrue));
    fprintf('    Model D (digits) : %-4d   digit confidences %.3f %.3f %.3f   %s\n', ...
            yD, conf(1), conf(2), conf(3), verdict(yD,ytrue));
    if yD ~= ytrue
        fprintf('    error = %+d  <-- carry failure, not an arithmetic slip\n', yD - ytrue);
    end

    clf;
    for k = 1:3
        ax = subplot(1,3,k);
        pk = Pq((k-1)*10 + (1:10));
        bar(ax, 0:9, pk, 'FaceColor', teal, 'EdgeColor','none'); hold(ax,'on');
        tk = [floor(ytrue/100), mod(floor(ytrue/10),10), mod(ytrue,10)];
        bar(ax, tk(k), pk(tk(k)+1), 'FaceColor', crimson, 'EdgeColor','none');
        ylim(ax,[0 1]); xlim(ax,[-0.6 9.6]); grid(ax,'on'); box(ax,'on');
        title(ax, sprintf('%s digit  (true = %d)', ttl{k}, tk(k)));
        xlabel(ax,'digit'); if k==1, ylabel(ax,'P(digit | x)'); end
    end
    sg2 = sgtitle(sprintf('x = %d  [%s]   model says %d,  truth %d', xq, seenTxt, yD, ytrue));
    set(sg2,'FontName','Times New Roman');
    drawnow;
end
fprintf('\n  Done.\n');

%% ==================================================================
%  LOCAL FUNCTIONS
%  ==================================================================

function [A, T] = build_data(xs)
    xs = xs(:);  n = numel(xs);
    A = zeros(n, 20);
    A(sub2ind([n 20], (1:n)', floor(xs/10) + 1))  = 1;
    A(sub2ind([n 20], (1:n)', mod(xs,10)  + 11))  = 1;
    y = 2*xs + 1;
    T = [floor(y/100), mod(floor(y/10),10), mod(y,10)];
end

function P = softmax_heads(Z)
    P = zeros(size(Z));
    for k = 1:3
        c  = (k-1)*10 + (1:10);
        Zk = Z(:,c) - max(Z(:,c),[],2);
        E  = exp(Zk);
        P(:,c) = E ./ sum(E,2);
    end
end

function y = predict_D(A, W1,b1,W2,b2)
    Z = tanh(A*W1 + b1)*W2 + b2;
    d = zeros(size(A,1),3);
    for k = 1:3
        [~, im] = max(Z(:, (k-1)*10 + (1:10)), [], 2);
        d(:,k) = im - 1;
    end
    y = d(:,1)*100 + d(:,2)*10 + d(:,3);
end

function s = verdict(a, b)
    if a == b, s = 'correct'; else, s = '<-- WRONG'; end
end
