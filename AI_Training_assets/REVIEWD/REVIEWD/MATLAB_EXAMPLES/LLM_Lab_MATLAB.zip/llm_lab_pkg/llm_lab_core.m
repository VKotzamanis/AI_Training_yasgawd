function [aTR, aTE, npar, out] = llm_lab_core(cfg)
%LLM_LAB_CORE  Headless version of LLM_LAB. No figures, no prompts.
%
%   [aTR, aTE, npar, out] = LLM_LAB_CORE(cfg)
%
%   cfg fields: RULE SPLIT TOKENS WIDTH DEPTH KMAX NOISE ITER ETA SEED
%   returns    exact-match accuracy on seen / held-out prompts, |theta|,
%              and a struct with the loss history, per-token accuracy and
%              the held-out error list.
%
%   Same equations as LLM_LAB:
%       z = W e + b,  P = softmax(z),  L = -mean log P(y|ctx),  dL/dz = P - e_y

rng(cfg.SEED);
XALL = 1:99;
[XTR, XTE] = split_x(XALL, cfg.SPLIT);
ND   = ndig_out(XALL, cfg.RULE, cfg.TOKENS);
[V, Vi] = make_vocab(XALL, cfg.RULE, cfg.TOKENS);
NV   = numel(V);
K    = cfg.KMAX;

Ytr  = corrupt(XTR, cfg.RULE, cfg.NOISE);
[Ctr, Ttr] = examples(XTR, Ytr, Vi, K, cfg.TOKENS, ND);
Atr  = encode(Ctr, NV);
n    = numel(Ttr);

dims = [K*NV, repmat(cfg.WIDTH,1,cfg.DEPTH), NV];
L    = numel(dims) - 1;
Ws = cell(1,L); Bs = cell(1,L);
for i = 1:L
    Ws{i} = randn(dims(i), dims(i+1)) * sqrt(2/dims(i));
    Bs{i} = zeros(1, dims(i+1));
end
npar = 0; for i = 1:L, npar = npar + numel(Ws{i}) + numel(Bs{i}); end

rows = (1:n)';
Lh   = zeros(1,cfg.ITER);
for t = 1:cfg.ITER
    acts = cell(1,L+1); acts{1} = Atr; H = Atr;
    for i = 1:cfg.DEPTH
        H = tanh(H*Ws{i} + Bs{i}); acts{i+1} = H;
    end
    Z  = H*Ws{L} + Bs{L};
    Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
    idx = sub2ind([n NV], rows, Ttr(:));
    Lh(t) = -sum(log(P(idx) + realmin))/n;
    G = P; G(idx) = G(idx) - 1; G = G/n;
    for i = L:-1:1
        dW = acts{i}'*G; dB = sum(G,1);
        if i > 1, G = (G*Ws{i}') .* (1 - acts{i}.^2); end
        Ws{i} = Ws{i} - cfg.ETA*dW;  Bs{i} = Bs{i} - cfg.ETA*dB;
    end
end

Yt = ruleval(XTR, cfg.RULE);  Ye = ruleval(XTE, cfg.RULE);
yTR = gen_batch(XTR, Ws,Bs,cfg.DEPTH,L, Vi,V,K,NV,cfg.TOKENS,ND);
yTE = gen_batch(XTE, Ws,Bs,cfg.DEPTH,L, Vi,V,K,NV,cfg.TOKENS,ND);
aTR = 100*mean(yTR == Yt(:));
aTE = 100*mean(yTE == Ye(:));

if nargout > 3
    out.L = Lh;  out.XTE = XTE;  out.yhat = yTE;  out.y = Ye(:);
    out.err = XTE(yTE ~= Ye(:));
    out.digit = nan(1,ND);
    if strcmp(cfg.TOKENS,'digit')
        for k = 1:ND
            p10 = 10^(ND-k);
            out.digit(k) = 100*mean(mod(floor(yTE/p10),10) == mod(floor(Ye(:)/p10),10));
        end
    end
end
end

% ---------------------------------------------------------------------

function y = ruleval(x, RULE)
    x = x(:)';
    switch RULE
        case 'copy',    y = x;
        case 'reverse', y = mod(x,10)*10 + floor(x/10);
        case 'x+7',     y = x + 7;
        case '2x+1',    y = 2*x + 1;
        case '3x',      y = 3*x;
        case 'x^2',     y = x.^2;
        otherwise, error('unknown RULE');
    end
end

function [XTR, XTE] = split_x(XALL, SPLIT)
    switch SPLIT
        case 'random'
            pm = randperm(numel(XALL));
            XTR = sort(XALL(pm(1:80)));  XTE = sort(XALL(pm(81:end)));
        case 'range'
            XTR = XALL(XALL <= 69);      XTE = XALL(XALL >= 70);
        case 'parity'
            s = floor(XALL/10) + mod(XALL,10);
            XTR = XALL(mod(s,2)==0);     XTE = XALL(mod(s,2)==1);
        otherwise, error('unknown SPLIT');
    end
end

function nd = ndig_out(XALL, RULE, TOKENS)
    if strcmp(TOKENS,'word'), nd = 1;
    else, nd = numel(sprintf('%d', max(ruleval(XALL,RULE)))); end
end

function [V, Vi] = make_vocab(XALL, RULE, TOKENS)
    if strcmp(TOKENS,'digit')
        V = [arrayfun(@(k) sprintf('%d',k), 0:9, 'UniformOutput', false), {'=','<eos>','<pad>'}];
    else
        yv = ruleval(XALL,RULE);
        u  = unique([XALL(:); yv(:)])';
        V  = [arrayfun(@(k) sprintf('%d',k), u, 'UniformOutput', false), {'=','<eos>','<pad>'}];
    end
    Vi = containers.Map(V, 1:numel(V));
end

function Y = corrupt(XTR, RULE, NOISE)
    Y = ruleval(XTR, RULE);
    if NOISE <= 0, return; end
    m   = rand(1,numel(XTR)) < NOISE;
    xs  = XTR(:)';
    alt = min(max(xs + (2*(rand(1,numel(xs))>0.5) - 1), 1), 99);
    Y(m) = ruleval(alt(m), RULE);
end

function s = seq_of(x, y, Vi, TOKENS, ND)
    if strcmp(TOKENS,'digit')
        sx = sprintf('%02d', x);  sy = sprintf(['%0' num2str(ND) 'd'], y);
        s = zeros(1, 2+1+ND+1);
        for i=1:2,  s(i)   = Vi(sx(i)); end
        s(3) = Vi('=');
        for i=1:ND, s(3+i) = Vi(sy(i)); end
        s(end) = Vi('<eos>');
    else
        s = [Vi(sprintf('%d',x)), Vi('='), Vi(sprintf('%d',y)), Vi('<eos>')];
    end
end

function c = pad_ctx(s, KMAX, Vi)
    s = s(max(1,numel(s)-KMAX+1):end);
    c = [repmat(Vi('<pad>'), 1, KMAX-numel(s)), s];
end

function [C, T] = examples(XTR, Ytr, Vi, KMAX, TOKENS, ND)
    C = []; T = [];
    if strcmp(TOKENS,'digit'), start = 4; else, start = 3; end
    for j = 1:numel(XTR)
        s = seq_of(XTR(j), Ytr(j), Vi, TOKENS, ND);
        for k = start:numel(s)
            C(end+1,:) = pad_ctx(s(1:k-1), KMAX, Vi); %#ok<AGROW>
            T(end+1,1) = s(k);                        %#ok<AGROW>
        end
    end
end

function A = encode(C, NV)
    [n, K] = size(C);  A = zeros(n, K*NV);
    for j = 1:K
        A(sub2ind([n K*NV], (1:n)', (j-1)*NV + C(:,j))) = 1;
    end
end

function P = fwd(A, Ws, Bs, DEPTH, L)
    H = A;
    for i = 1:DEPTH, H = tanh(H*Ws{i} + Bs{i}); end
    Z = H*Ws{L} + Bs{L};
    Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
end

function y = gen_batch(xs, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND)
    xs = xs(:); n = numel(xs);
    if n == 0, y = zeros(0,1); return; end
    S = zeros(n,0);
    for j = 1:n
        if strcmp(TOKENS,'digit')
            sx = sprintf('%02d', xs(j));
            S(j,1:3) = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
        else
            S(j,1:2) = [Vi(sprintf('%d',xs(j))), Vi('=')];
        end
    end
    out = zeros(n,ND);
    for k = 1:ND
        C = zeros(n,KMAX);
        for j = 1:n, C(j,:) = pad_ctx(S(j,:), KMAX, Vi); end
        P = fwd(encode(C,NV), Ws,Bs,DEPTH,L);
        [~, nx] = max(P,[],2);
        out(:,k) = nx;  S = [S, nx]; %#ok<AGROW>
    end
    y = zeros(n,1);
    for j = 1:n
        if strcmp(TOKENS,'word')
            v = str2double(V{out(j,1)});
            if isnan(v), v = -1; end
            y(j) = v;
        else
            v = 0; ok = true;
            for k = 1:ND
                d = str2double(V{out(j,k)});
                if isnan(d), ok = false; break; end
                v = v*10 + d;
            end
            if ok, y(j) = v; else, y(j) = -1; end
        end
    end
end
