%% LLM_LAB_LEARN  What the model learns, drawn while it learns it.
%
%  Panel 1  P(final character | input ones digit), as a 10 x 10 map.
%           Circles mark the true map. Rows are inputs, columns are outputs.
%
%  Panel 2  yhat against y over all 99 inputs, seen and held out, with y = yhat.
%
%  Both update during training. Afterwards you can type any prompt, including
%  a word, and see what comes back.
%
%  The vocabulary includes a-z so that non-numeric prompts can be encoded at
%  all. No letter ever appears in the training corpus.
%
%  Base MATLAB only. No toolboxes. Runs in GNU Octave.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
cA = [15 77 89]/255;  cB = [156 28 36]/255;

%% ================== PARAMETERS =====================================
RULE  = @(x) 2*x + 1;
WIDTH = 32;   DEPTH = 1;   KMAX = 8;
ITER  = 8000; ETA = 0.5;   SEED = 0;
%% ===================================================================

V  = [arrayfun(@(k) sprintf('%d',k), 0:9, 'UniformOutput', false), ...
      num2cell('abcdefghijklmnopqrstuvwxyz'), {'.','-','=','<eos>','<pad>'}];
Vi = containers.Map(V, 1:numel(V));  NV = numel(V);

XA  = 1:99;  s = floor(XA/10) + mod(XA,10);
XTR = XA(mod(s,2)==0);   XTE = XA(mod(s,2)==1);
Y   = RULE(double(XA));
ND  = numel(sprintf('%d', max(Y)));
fmt = @(v) sprintf('%0*d', ND, round(v));

[C,T] = build(XTR, RULE, fmt, Vi, KMAX);
A = encode(C,NV);  n = numel(T);  rows = (1:n)';
idx = sub2ind([n NV], rows, T(:));

rng(SEED);
dims = [KMAX*NV, repmat(WIDTH,1,DEPTH), NV];  L = numel(dims)-1;
Ws = cell(1,L); Bs = cell(1,L);
for i = 1:L
    Ws{i} = randn(dims(i),dims(i+1))*sqrt(2/dims(i));
    Bs{i} = zeros(1,dims(i+1));
end

trueMap = mod(2*(0:9)+1, 10);          % only exact for RULE = 2x+1
cm = [linspace(1,cA(1),256)', linspace(1,cA(2),256)', linspace(1,cA(3),256)'];

figure('Color','w','Position',[60 80 1120 470]);
ax1 = subplot(1,2,1);
h1  = imagesc(ax1, 0:9, 0:9, zeros(10)); set(ax1,'YDir','normal');
colormap(ax1, cm); caxis(ax1,[0 1]); colorbar(ax1);
hold(ax1,'on');
plot(ax1, trueMap, 0:9, 'o', 'MarkerEdgeColor', cB, 'MarkerSize', 11, 'LineWidth', 1.6);
set(ax1,'XTick',0:9,'YTick',0:9); axis(ax1,'square');
xlabel(ax1,'emitted character'); ylabel(ax1,'input ones digit');

ax2 = subplot(1,2,2);
h2a = plot(ax2, nan, nan, 'o', 'MarkerFaceColor', cA, 'MarkerEdgeColor','none','MarkerSize',5); hold(ax2,'on');
h2b = plot(ax2, nan, nan, 'o', 'MarkerFaceColor', cB, 'MarkerEdgeColor','none','MarkerSize',5);
plot(ax2, [0 max(Y)], [0 max(Y)], '-', 'Color',[.6 .6 .6], 'LineWidth', 1.2);
xlim(ax2,[0 max(Y)]); ylim(ax2,[0 max(Y)]); axis(ax2,'square');
grid(ax2,'on'); box(ax2,'on');
xlabel(ax2,'{\it y}'); ylabel(ax2,'$\hat{y}$','Interpreter','latex');
lg = legend(ax2,{'seen','held out'},'Location','southeast'); set(lg,'Box','off');

CK = unique(round(logspace(0, log10(ITER), 45)));
for t = 1:ITER
    acts = cell(1,L+1); acts{1} = A; H = A;
    for i = 1:DEPTH, H = tanh(H*Ws{i}+Bs{i}); acts{i+1} = H; end
    Z = H*Ws{L}+Bs{L};
    Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
    G = P; G(idx) = G(idx)-1; G = G/n;
    for i = L:-1:1
        dW = acts{i}'*G; dB = sum(G,1);
        if i > 1, G = (G*Ws{i}').*(1-acts{i}.^2); end
        Ws{i} = Ws{i}-ETA*dW; Bs{i} = Bs{i}-ETA*dB;
    end

    if any(t == CK)
        M = charmap(Ws,Bs,DEPTH,L,Vi,KMAX,NV,ND);
        set(h1,'CData',M);
        yh = zeros(1,99);
        for j = 1:99
            g = gen_str(j, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,ND);
            v = str2double(g); if isnan(v), v = -1; end
            yh(j) = v;
        end
        set(h2a,'XData',Y(XTR),'YData',yh(XTR));
        set(h2b,'XData',Y(XTE),'YData',yh(XTE));
        title(ax1, sprintf('t = %d', t));
        title(ax2, sprintf('held out %.0f %%', 100*mean(yh(XTE) == Y(XTE))));
        drawnow;
    end
end

fprintf('\nlearned map, input ones digit -> emitted character\n  ');
M = charmap(Ws,Bs,DEPTH,L,Vi,KMAX,NV,ND);
[~, am] = max(M,[],2);
for d = 0:9, fprintf('%d->%d  ', d, am(d+1)-1); end
fprintf('\n\n');

%% ---- free-text prompt ----------------------------------------------
fprintf('type any prompt (digits or letters), blank line to stop\n');
while true
    q = input('  prompt: ','s');
    if isempty(q), break; end
    q = lower(strtrim(q));
    ok = true; tk = zeros(1,numel(q));
    for i = 1:numel(q)
        if isKey(Vi, q(i)), tk(i) = Vi(q(i)); else, ok = false; break; end
    end
    if ~ok, fprintf('    character not in vocabulary\n'); continue; end
    ctx = [tk, Vi('=')];
    out = ''; conf = zeros(1,ND);
    for k = 1:ND
        Pk = fwd(encode(pad_ctx(ctx,KMAX,Vi),NV), Ws,Bs,DEPTH,L);
        [conf(k), nx] = max(Pk);
        out = [out V{nx}]; ctx = [ctx nx]; %#ok<AGROW>
    end
    fprintf('    -> %s    per-character confidence %s\n', out, sprintf('%.3f ',conf));
end

%% ===================================================================
function [C,T] = build(XS, R, fmt, Vi, KMAX)
    C = []; T = [];
    for j = 1:numel(XS)
        sx = sprintf('%02d', XS(j));  sy = fmt(R(double(XS(j))));
        s = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
        for i = 1:numel(sy), s(end+1) = Vi(sy(i)); end %#ok<AGROW>
        s(end+1) = Vi('<eos>');
        for k = 4:numel(s)
            C(end+1,:) = pad_ctx(s(1:k-1), KMAX, Vi); %#ok<AGROW>
            T(end+1,1) = s(k);                        %#ok<AGROW>
        end
    end
end

function c = pad_ctx(s, KMAX, Vi)
    s = s(max(1,numel(s)-KMAX+1):end);
    c = [repmat(Vi('<pad>'), 1, KMAX-numel(s)), s];
end

function A = encode(C, NV)
    [n,K] = size(C); A = zeros(n, K*NV);
    for j = 1:K
        A(sub2ind([n K*NV], (1:n)', (j-1)*NV + C(:,j))) = 1;
    end
end

function P = fwd(A, Ws, Bs, DEPTH, L)
    H = A;
    for i = 1:DEPTH, H = tanh(H*Ws{i}+Bs{i}); end
    Z = H*Ws{L}+Bs{L};
    Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
end

function M = charmap(Ws,Bs,DEPTH,L,Vi,KMAX,NV,ND)
%CHARMAP P(final emitted character | input ones digit), digits only.
    M = zeros(10,10);
    for d = 0:9
        sx = sprintf('2%d', d);
        ctx = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
        for k = 1:ND-1
            P = fwd(encode(pad_ctx(ctx,KMAX,Vi),NV), Ws,Bs,DEPTH,L);
            [~,nx] = max(P); ctx = [ctx nx]; %#ok<AGROW>
        end
        P = fwd(encode(pad_ctx(ctx,KMAX,Vi),NV), Ws,Bs,DEPTH,L);
        M(d+1,:) = P(1:10);
    end
end

function out = gen_str(x, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,ND)
    sx = sprintf('%02d', x);
    ctx = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
    out = '';
    for k = 1:ND
        P = fwd(encode(pad_ctx(ctx,KMAX,Vi),NV), Ws,Bs,DEPTH,L);
        [~,nx] = max(P);
        out = [out V{nx}]; ctx = [ctx nx]; %#ok<AGROW>
    end
end
