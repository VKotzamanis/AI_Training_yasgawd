%% LLM_LAB_COMPARE  Three rules, one prompt, six panels.
%
%  Column 1   y = 2x+1        token-local: each output character depends on a
%                             bounded window of input characters plus a carry
%  Column 2   y = ln(x)       not token-local: every output character depends
%                             on the whole input
%  Column 3   whatever the user types
%
%  Row 1   P(v | ctx) at the first generated character, for the SAME held-out
%          prompt in all three columns. The true character is marked.
%  Row 2   L(theta) on the training corpus and on the held-out corpus.
%
%  The point of the figure is that the training curves are indistinguishable.
%
%  Base MATLAB only. No toolboxes. Runs in GNU Octave.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
cA = [15 77 89]/255;  cB = [156 28 36]/255;  cG = [150 150 150]/255;

%% ================== PARAMETERS =====================================
XPROBE = 50;        % the held-out prompt shown in row 1 (same for all columns)
WIDTH  = 32;
DEPTH  = 1;
KMAX   = 8;
ITER   = 8000;
ETA    = 0.5;
SEED   = 0;
DEC3   = 3;         % decimal places for the user rule, if it is non-integer
%% ===================================================================

fprintf('enter a rule in x, e.g.  x^2+2*x-1   or   sqrt(x)   or   exp(-x/10)\n');
ustr = input('  y = ', 's');
if isempty(ustr), ustr = 'sqrt(x)'; fprintf('  using %s\n', ustr); end
[ufun, uerr] = parse_rule(ustr);
if ~isempty(uerr), error('rule rejected: %s', uerr); end

RULES = { @(x) 2*x+1, @(x) log(x), ufun };
NAMES = { 'y = 2x+1',  'y = ln(x)', ['y = ' ustr] };
DECS  = [ 0, DEC3, DEC3 ];

XALL = 1:99;
s    = floor(XALL/10) + mod(XALL,10);
XTR  = XALL(mod(s,2)==0);
XTE  = XALL(mod(s,2)==1);
if ~any(XTE == XPROBE)
    [~,j] = min(abs(XTE - XPROBE));  XPROBE = XTE(j);
    fprintf('  probe moved to nearest held-out prompt: x = %d\n', XPROBE);
end

[V, Vi] = char_vocab();  NV = numel(V);
fig = figure('Color','w','Position',[40 40 1240 620]);

for c = 1:3
    R = RULES{c};  DEC = DECS(c);
    [fmt, ND, ok, msg] = make_fmt(XALL, R, DEC);
    if ~ok, error('column %d: %s', c, msg); end

    [Ws,Bs,L,Ltr,Lte,ck] = train_col(XTR, XTE, R, fmt, ND, Vi, NV, ...
                                     KMAX, WIDTH, DEPTH, ITER, ETA, SEED);

    ctx  = seed_ctx(XPROBE, Vi, KMAX);
    P1   = fwd(encode(ctx,NV), Ws,Bs,DEPTH,L);
    ytrue = fmt(R(double(XPROBE)));
    ttrue = Vi(ytrue(1));
    yhat  = gen_str(XPROBE, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,ND);

    acc = 0;
    for j = 1:numel(XTE)
        if strcmp(gen_str(XTE(j),Ws,Bs,DEPTH,L,Vi,V,KMAX,NV,ND), fmt(R(double(XTE(j)))))
            acc = acc + 1;
        end
    end
    acc = 100*acc/numel(XTE);

    fprintf('%-16s  L_train = %.4f   L_held = %.4f   held-out = %5.1f %%   x=%d -> %s (true %s)\n', ...
            NAMES{c}, Ltr(end), Lte(end), acc, XPROBE, yhat, ytrue);

    ax = subplot(2,3,c);
    bar(ax, 1:NV, P1, 'FaceColor', cA, 'EdgeColor','none'); hold(ax,'on');
    bar(ax, ttrue, P1(ttrue), 'FaceColor', cB, 'EdgeColor','none');
    set(ax,'XTick',1:NV,'XTickLabel',V,'XTickLabelRotation',90);
    xlim(ax,[0.4 NV+0.6]); ylim(ax,[0 1]); grid(ax,'on'); box(ax,'on');
    ylabel(ax,'{\it P}({\it v} | ctx)');
    title(ax, NAMES{c});

    ax = subplot(2,3,3+c);
    loglog(ax, 1:ITER, max(Ltr,1e-12), '-', 'Color', cA, 'LineWidth', 1.8); hold(ax,'on');
    loglog(ax, ck, max(Lte,1e-12), '-', 'Color', cB, 'LineWidth', 1.8);
    loglog(ax, [1 ITER], log(NV)*[1 1], '--', 'Color', cG, 'LineWidth', 1.2);
    xlim(ax,[1 ITER]); ylim(ax,[1e-5 10]); grid(ax,'on'); box(ax,'on');
    set(ax,'YTick',10.^(-5:1));
    xlabel(ax,'{\it t}'); ylabel(ax,'{\it L}(\theta)   [nats]');
    if c == 1
        lg = legend(ax, {'train','held out','ln|{\it V}|'}, 'Location','southwest');
        set(lg,'Box','off');
    end
end

%% ===================================================================
%  FUNCTIONS
%  ===================================================================

function [f, err] = parse_rule(str)
%PARSE_RULE Whitelist-validated symbolic rule -> vectorised function handle.
%   Only digits, x, arithmetic, brackets and a fixed list of function names
%   are permitted. Anything else is rejected without being evaluated.
    f = []; err = '';
    s = lower(regexprep(str, '\s', ''));
    if isempty(s), err = 'empty'; return; end
    ok = {'log10','log2','log','exp','sqrt','abs','sinh','cosh','tanh', ...
          'sin','cos','tan','floor','ceil','round','mod','pi'};
    t = s;
    for i = 1:numel(ok), t = strrep(t, ok{i}, ''); end
    bad = regexp(t, '[^0-9x+\-*/^().,]', 'match', 'once');
    if ~isempty(bad), err = sprintf('disallowed character ''%s''', bad); return; end
    s = regexprep(s, '\.([\^*/])', '$1');     % normalise existing dot-operators
    s = regexprep(s, '([\^*/])',  '.$1');     % vectorise
    try
        f = str2func(['@(x) ' s]);
        v = f(double(1:99));
        if numel(v) ~= 99,        err = 'not vectorised';        f = []; return; end
        if ~isreal(v),            err = 'complex output';        f = []; return; end
        if any(~isfinite(v)),     err = 'non-finite output';     f = []; return; end
    catch e
        err = e.message; f = [];
    end
end

function [V, Vi] = char_vocab()
    V  = [arrayfun(@(k) sprintf('%d',k), 0:9, 'UniformOutput', false), ...
          {'.','-','=','<eos>','<pad>'}];
    Vi = containers.Map(V, 1:numel(V));
end

function [fmt, W, ok, msg] = make_fmt(XALL, R, DEC)
%MAKE_FMT Fixed-width string formatter. Every y renders to the same width.
    ok = true; msg = ''; W = 0; fmt = [];
    Y = R(double(XALL));
    if any(~isfinite(Y)) || ~isreal(Y), ok = false; msg = 'rule not finite/real on 1..99'; return; end
    if DEC <= 0 && all(abs(Y - round(Y)) < 1e-9)
        w = numel(sprintf('%d', max(abs(round(Y)))));
        f0 = @(v) [repmat('-',1,double(v<0)) sprintf('%0*d', w, abs(round(v)))];
    else
        ip = numel(sprintf('%d', floor(max(abs(Y)))));
        f0 = @(v) [repmat('-',1,double(v<0)) sprintf('%0*.*f', ip+DEC+1, DEC, abs(v))];
    end
    for j = 1:numel(Y), W = max(W, numel(f0(Y(j)))); end
    fmt = @(v) sprintf('%*s', W, f0(v));
    if W > 8, ok = false; msg = sprintf('output width %d too large; lower DEC', W); end
end

function s = seq_of(x, y, Vi, fmt)
    sx = sprintf('%02d', x);  sy = fmt(y);
    s = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
    for i = 1:numel(sy), s(end+1) = Vi(sy(i)); end %#ok<AGROW>
    s(end+1) = Vi('<eos>');
end

function c = pad_ctx(s, KMAX, Vi)
    s = s(max(1,numel(s)-KMAX+1):end);
    c = [repmat(Vi('<pad>'), 1, KMAX-numel(s)), s];
end

function c = seed_ctx(x, Vi, KMAX)
    sx = sprintf('%02d', x);
    c  = pad_ctx([Vi(sx(1)), Vi(sx(2)), Vi('=')], KMAX, Vi);
end

function [C, T] = examples(XS, R, fmt, Vi, KMAX)
    C = []; T = [];
    for j = 1:numel(XS)
        s = seq_of(XS(j), R(double(XS(j))), Vi, fmt);
        for k = 4:numel(s)
            C(end+1,:) = pad_ctx(s(1:k-1), KMAX, Vi); %#ok<AGROW>
            T(end+1,1) = s(k);                        %#ok<AGROW>
        end
    end
end

function A = encode(C, NV)
    [n, K] = size(C);  A = zeros(n, K*NV);
    for j = 1:K
        A(sub2ind([n K*NV], (1:n)', (j-1)*NV + C(:,j))) = 1;
    end
end

function P = fwd(A, Ws, Bs, DEPTH, L)
    H = A;
    for i = 1:DEPTH, H = tanh(H*Ws{i} + Bs{i}); end
    Z = H*Ws{L} + Bs{L};
    Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
end

function [Ws,Bs,L,Ltr,Lte,ck] = train_col(XTR,XTE,R,fmt,ND,Vi,NV,KMAX,WIDTH,DEPTH,ITER,ETA,SEED)
    rng(SEED);
    [Ctr,Ttr] = examples(XTR, R, fmt, Vi, KMAX);  Atr = encode(Ctr,NV);
    [Cte,Tte] = examples(XTE, R, fmt, Vi, KMAX);  Ate = encode(Cte,NV);
    n = numel(Ttr);  m = numel(Tte);
    dims = [KMAX*NV, repmat(WIDTH,1,DEPTH), NV];  L = numel(dims)-1;
    Ws = cell(1,L); Bs = cell(1,L);
    for i = 1:L
        Ws{i} = randn(dims(i),dims(i+1))*sqrt(2/dims(i));
        Bs{i} = zeros(1,dims(i+1));
    end
    rows = (1:n)';  idx = sub2ind([n NV], rows, Ttr(:));
    Ltr  = zeros(1,ITER);
    ck   = unique(round(logspace(0, log10(ITER), 60)));
    Lte  = zeros(1,numel(ck));  q = 1;
    for t = 1:ITER
        acts = cell(1,L+1); acts{1} = Atr; H = Atr;
        for i = 1:DEPTH, H = tanh(H*Ws{i}+Bs{i}); acts{i+1} = H; end
        Z = H*Ws{L}+Bs{L};
        Zs = Z - max(Z,[],2); E = exp(Zs); P = E ./ sum(E,2);
        Ltr(t) = -sum(log(P(idx)+realmin))/n;
        G = P; G(idx) = G(idx)-1; G = G/n;
        for i = L:-1:1
            dW = acts{i}'*G; dB = sum(G,1);
            if i > 1, G = (G*Ws{i}').*(1-acts{i}.^2); end
            Ws{i} = Ws{i}-ETA*dW; Bs{i} = Bs{i}-ETA*dB;
        end
        if q <= numel(ck) && t == ck(q)
            Pe = fwd(Ate, Ws,Bs,DEPTH,L);
            Lte(q) = -sum(log(Pe(sub2ind([m NV],(1:m)',Tte(:)))+realmin))/m;
            q = q+1;
        end
    end
end

function out = gen_str(x, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,ND)
    sx = sprintf('%02d', x);
    ctx = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
    out = '';
    for k = 1:ND
        P = fwd(encode(pad_ctx(ctx,KMAX,Vi),NV), Ws,Bs,DEPTH,L);
        [~, nx] = max(P);
        out = [out V{nx}]; %#ok<AGROW>
        ctx = [ctx nx];    %#ok<AGROW>
    end
end
