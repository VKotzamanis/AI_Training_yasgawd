%% LLM_LAB_SWEEP  Batch experiments. No animation, no prompt loop.
%
%  Reproduces the four experiments in the worksheet. Each block varies ONE
%  factor and holds the rest fixed. Run the whole file, or one block at a time.
%
%  Requires llm_lab_core.m on the path.
%
%  Runtime: a few minutes. Reduce SEEDS to 1 for a quick pass.

clear; close all; clc;
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
cA = [15 77 89]/255;  cB = [156 28 36]/255;

SEEDS = 3;
base  = struct('RULE','2x+1','SPLIT','parity','TOKENS','digit', ...
               'WIDTH',32,'DEPTH',1,'KMAX',6,'NOISE',0.00, ...
               'ITER',8000,'ETA',0.5,'SEED',0);

%% ---- E1  representation -------------------------------------------
fprintf('E1  TOKENS\n');
fprintf('  %-8s %10s %10s %10s\n','tokens','|theta|','seen','held out');
tk = {'word','digit'};  E1 = zeros(2,2);
for i = 1:2
    c = base; c.TOKENS = tk{i};
    [a,b,np_] = repeat(c, SEEDS);
    E1(i,:) = [a b];
    fprintf('  %-8s %10d %9.1f%% %9.1f%%\n', tk{i}, np_, a, b);
end

%% ---- E2  rule ------------------------------------------------------
fprintf('\nE2  RULE\n');
fprintf('  %-9s %10s %10s\n','rule','seen','held out');
rl = {'copy','reverse','2x+1','x+7','3x','x^2'};  E2 = zeros(numel(rl),2);
for i = 1:numel(rl)
    c = base; c.RULE = rl{i};
    [a,b] = repeat(c, SEEDS);
    E2(i,:) = [a b];
    fprintf('  %-9s %9.1f%% %9.1f%%\n', rl{i}, a, b);
end

%% ---- E3  split -----------------------------------------------------
fprintf('\nE3  SPLIT\n');
fprintf('  %-9s %10s %10s %10s\n','rule','random','range','parity');
sp = {'random','range','parity'};  rl3 = {'2x+1','x+7','3x'};
E3 = zeros(numel(rl3), numel(sp));
for i = 1:numel(rl3)
    for j = 1:numel(sp)
        c = base; c.RULE = rl3{i}; c.SPLIT = sp{j};
        [~,b] = repeat(c, SEEDS);  E3(i,j) = b;
    end
    fprintf('  %-9s %9.1f%% %9.1f%% %9.1f%%\n', rl3{i}, E3(i,1), E3(i,2), E3(i,3));
end

%% ---- E4  width x depth ---------------------------------------------
fprintf('\nE4  WIDTH x DEPTH   (rule x+7, parity)\n');
wd = [8 32 128];  dp = [0 1 2 3];
E4 = zeros(numel(wd), numel(dp));  E4p = zeros(numel(wd), numel(dp));
fprintf('  %-8s','width\\depth'); fprintf('%10d', dp); fprintf('\n');
for i = 1:numel(wd)
    for j = 1:numel(dp)
        c = base; c.RULE = 'x+7'; c.WIDTH = wd(i); c.DEPTH = dp(j);
        [~,b,np_] = repeat(c, SEEDS);
        E4(i,j) = b;  E4p(i,j) = np_;
    end
    fprintf('  %-8d', wd(i)); fprintf('%9.1f%%', E4(i,:)); fprintf('\n');
end

%% ---- E5  corpus noise ----------------------------------------------
fprintf('\nE5  NOISE\n');
fprintf('  %-8s %10s %10s\n','noise','seen','held out');
nz = [0 0.05 0.10 0.20 0.40];  E5 = zeros(numel(nz),2);
for i = 1:numel(nz)
    c = base; c.NOISE = nz(i);
    [a,b] = repeat(c, SEEDS);
    E5(i,:) = [a b];
    fprintf('  %-8.2f %9.1f%% %9.1f%%\n', nz(i), a, b);
end

%% ---- figures --------------------------------------------------------
figure('Color','w','Position',[60 60 1100 340]);

subplot(1,3,1);
bar(E2, 'grouped'); colormap([cA; cB]);
set(gca,'XTick',1:numel(rl),'XTickLabel',rl,'XTickLabelRotation',30);
ylabel('exact match   [%]'); ylim([0 105]); grid on; box on;
lg = legend({'seen','held out'},'Location','southwest'); set(lg,'Box','off');

subplot(1,3,2);
plot(dp, E4(1,:), '-o','Color',cA,'LineWidth',1.6,'MarkerFaceColor',cA); hold on;
plot(dp, E4(2,:), '-s','Color',cB,'LineWidth',1.6,'MarkerFaceColor',cB);
plot(dp, E4(3,:), '-^','Color',[.4 .4 .4],'LineWidth',1.6,'MarkerFaceColor',[.4 .4 .4]);
set(gca,'XTick',dp); xlabel('depth'); ylabel('held out   [%]');
ylim([0 105]); grid on; box on;
lg = legend({'width 8','width 32','width 128'},'Location','northwest'); set(lg,'Box','off');

subplot(1,3,3);
plot(nz, E5(:,1), '-o','Color',cA,'LineWidth',1.6,'MarkerFaceColor',cA); hold on;
plot(nz, E5(:,2), '-s','Color',cB,'LineWidth',1.6,'MarkerFaceColor',cB);
xlabel('corpus noise fraction'); ylabel('exact match   [%]');
ylim([0 105]); grid on; box on;
lg = legend({'seen','held out'},'Location','southwest'); set(lg,'Box','off');

%% ---- helper ---------------------------------------------------------
function [aTR, aTE, npar] = repeat(cfg, SEEDS)
    A = zeros(1,SEEDS);  B = zeros(1,SEEDS);
    for s = 1:SEEDS
        cfg.SEED = s-1;
        [A(s), B(s), npar] = llm_lab_core(cfg);
    end
    aTR = mean(A);  aTE = mean(B);
end
