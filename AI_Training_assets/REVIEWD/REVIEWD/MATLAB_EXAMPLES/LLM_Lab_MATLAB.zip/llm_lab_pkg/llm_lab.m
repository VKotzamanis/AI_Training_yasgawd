%% LLM_LAB  A minimal autoregressive language model, trained on arithmetic.
%
%  The model implements exactly the equations on the lecture slides:
%
%      z        = W e + b                      (logits from the context tokens)
%      P(v|ctx) = exp(z_v) / sum_j exp(z_j)     (softmax over the vocabulary)
%      L(theta) = -(1/N) sum log P(y_i | ctx_i) (cross-entropy)
%      dL/dz    = P - e_y                       (the residual)
%      yhat     = argmax_v P(v | ctx)           (greedy decoding)
%
%  Output tokens are generated ONE AT A TIME and fed back as context, which is
%  what makes this autoregressive rather than a parallel classifier.
%
%  DEPTH = 0 is the bare equation above. DEPTH > 0 inserts tanh layers.
%
%  Base MATLAB only. No toolboxes. Runs in GNU Octave.

clear; close all; clc;

%% ================== PARAMETERS =====================================
RULE   = '2x+1';    % 'copy' | 'reverse' | 'x+7' | '2x+1' | '3x' | 'x^2'
SPLIT  = 'parity';  % 'random' | 'range' | 'parity'
TOKENS = 'digit';   % 'digit' | 'word'
WIDTH  = 32;        % units per hidden layer
DEPTH  = 1;         % number of hidden layers (0 = bare slide equation)
KMAX   = 6;         % context window, in tokens
NOISE  = 0.00;      % fraction of the corpus that violates the rule
ITER   = 8000;
ETA    = 0.5;
SEED   = 0;
%% ===================================================================

rng(SEED);
set(0,'defaultAxesFontName','Times New Roman');
set(0,'defaultTextFontName','Times New Roman');
cA = [15  77 89]/255;   cB = [156 28 36]/255;   cC = [140 140 140]/255;

%% ---- corpus ------------------------------------------------------
XALL = 1:99;
[XTR, XTE] = split_x(XALL, SPLIT);
ND   = ndig_out(XALL, RULE, TOKENS);
[V, Vi] = make_vocab(XALL, RULE, TOKENS);
NV   = numel(V);
NIN  = KMAX*NV;

Ytr  = corrupt(XTR, RULE, NOISE);
[Ctr, Ttr] = examples(XTR, Ytr, Vi, KMAX, TOKENS, ND);
Atr  = encode(Ctr, NV);
n    = numel(Ttr);

fprintf('rule %s | split %s | tokens %s | width %d | depth %d | kmax %d | noise %.2f\n', ...
        RULE, SPLIT, TOKENS, WIDTH, DEPTH, KMAX, NOISE);
fprintf('|V| = %d   train x: %d   held-out x: %d   training positions: %d\n\n', ...
        NV, numel(XTR), numel(XTE), n);

%% ---- parameters --------------------------------------------------
dims = [NIN, repmat(WIDTH,1,DEPTH), NV];
L    = numel(dims) - 1;
Ws   = cell(1,L);  Bs = cell(1,L);
for i = 1:L
    Ws{i} = randn(dims(i), dims(i+1)) * sqrt(2/dims(i));
    Bs{i} = zeros(1, dims(i+1));
end
npar = 0; for i = 1:L, npar = npar + numel(Ws{i}) + numel(Bs{i}); end
fprintf('|theta| = %d\n\n', npar);

%% ---- probe used by the live panels --------------------------------
%  Probe the output position carrying the most information. Position 1 is the
%  most significant token and is often near-constant (leading zero), which
%  makes it useless to watch.
if strcmp(TOKENS,'digit'), off = 3; else, off = 2; end
Hpos = zeros(1,ND);
for k = 1:ND
    tk = zeros(numel(XTR),1);
    for j = 1:numel(XTR)
        sj = seq_of(XTR(j), Ytr(j), Vi, TOKENS, ND);
        tk(j) = sj(off+k);
    end
    pk = accumarray(tk, 1, [NV 1]) / numel(tk);
    pk = pk(pk > 0);
    Hpos(k) = -sum(pk .* log(pk));
end
[~, kp] = max(Hpos);

%  Among the held-out prompts, probe the one whose target token at position kp
%  is rarest in the training corpus. Probing a common token shows nothing.
if isempty(XTE), Xp = XTR; else, Xp = XTE; end
fq = zeros(NV,1);
for j = 1:numel(XTR)
    sj = seq_of(XTR(j), Ytr(j), Vi, TOKENS, ND);
    fq(sj(off+kp)) = fq(sj(off+kp)) + 1;
end
cand = zeros(1,numel(Xp));
for j = 1:numel(Xp)
    sj = seq_of(Xp(j), ruleval(Xp(j),RULE), Vi, TOKENS, ND);
    cand(j) = sj(off+kp);
end
[~, jmin] = min(fq(cand));
xp = Xp(jmin);
sp   = seq_of(xp, ruleval(xp,RULE), Vi, TOKENS, ND);
ctxp = pad_ctx(sp(1:off+kp-1), KMAX, Vi);
Ap   = encode(ctxp, NV);
tp   = sp(off+kp);
ep   = zeros(1,NV); ep(tp) = 1;

fprintf('probe: x = %d, output position %d of %d, target token "%s"\n', ...
        xp, kp, ND, V{tp});
fprintf('position entropy [nats]:'); fprintf(' %.3f', Hpos); fprintf('\n\n');

%% ---- live figure --------------------------------------------------
fig = figure('Color','w','Position',[60 60 1120 720]);

ax1 = subplot(2,2,1);
h1a = plot(ax1,nan,nan,'-','Color',cA,'LineWidth',1.8); hold(ax1,'on');
h1b = plot(ax1,nan,nan,'-','Color',cB,'LineWidth',1.8);
set(ax1,'XScale','log','YScale','log','YTick',10.^(-5:1));
grid(ax1,'on'); box(ax1,'on');
xlim(ax1,[1 ITER]); ylim(ax1,[1e-5 10]);
xlabel(ax1,'t'); ylabel(ax1,'{\it L}(\theta)   [nats]');
lg1 = legend(ax1,{'train','held-out'},'Location','northeast'); set(lg1,'Box','off');

ax2 = subplot(2,2,2);
h2a = plot(ax2,nan,nan,'-o','Color',cA,'LineWidth',1.8,'MarkerSize',4,'MarkerFaceColor',cA); hold(ax2,'on');
h2b = plot(ax2,nan,nan,'-o','Color',cB,'LineWidth',1.8,'MarkerSize',4,'MarkerFaceColor',cB);
set(ax2,'XScale','log'); grid(ax2,'on'); box(ax2,'on');
xlim(ax2,[1 ITER]); ylim(ax2,[-2 102]);
xlabel(ax2,'t'); ylabel(ax2,'exact match   [%]');
lg2 = legend(ax2,{'train','held-out'},'Location','southeast'); set(lg2,'Box','off');

ax3 = subplot(2,2,3);
h3 = bar(ax3, 1:NV, zeros(1,NV), 'FaceColor', cA, 'EdgeColor','none');
set(ax3,'XTick',1:NV,'XTickLabel',V,'XTickLabelRotation',90);
xlim(ax3,[0.4 NV+0.6]); ylim(ax3,[0 1]); grid(ax3,'on'); box(ax3,'on');
xlabel(ax3,'{\it v} \in {\it V}'); ylabel(ax3,'{\it P}({\it v} | ctx)');
title(ax3, sprintf('x = %d,  position %d', xp, kp));

ax4 = subplot(2,2,4);
h4 = bar(ax4, 1:NV, zeros(1,NV), 'FaceColor', cB, 'EdgeColor','none');
set(ax4,'XTick',1:NV,'XTickLabel',V,'XTickLabelRotation',90);
xlim(ax4,[0.4 NV+0.6]); ylim(ax4,[-1.05 1.05]); grid(ax4,'on'); box(ax4,'on');
xlabel(ax4,'{\it v} \in {\it V}'); ylabel(ax4,'{\it P} - {\it e}_y');
title(ax4, sprintf('x = %d,  position %d', xp, kp));

%% ---- training -----------------------------------------------------
Lh = nan(1,ITER);  ck = [];  ckLte = [];  ckTr = [];  ckTe = [];
CKPT = unique(round(logspace(0, log10(ITER), 40)));
Yte = ruleval(XTE, RULE);
Yt2 = ruleval(XTR, RULE);
rows = (1:n)';

for t = 1:ITER
    acts = cell(1,L+1);  acts{1} = Atr;  H = Atr;
    for i = 1:DEPTH
        H = tanh(H*Ws{i} + Bs{i});  acts{i+1} = H;
    end
    Z = H*Ws{L} + Bs{L};
    Zs = Z - max(Z,[],2);  E = exp(Zs);  P = E ./ sum(E,2);

    idx   = sub2ind([n NV], rows, Ttr(:));
    Lh(t) = -sum(log(P(idx) + realmin))/n;

    G = P;  G(idx) = G(idx) - 1;  G = G/n;
    for i = L:-1:1
        dW = acts{i}'*G;  dB = sum(G,1);
        if i > 1, G = (G*Ws{i}') .* (1 - acts{i}.^2); end
        Ws{i} = Ws{i} - ETA*dW;  Bs{i} = Bs{i} - ETA*dB;
    end

    if any(t == CKPT) || mod(t,200) == 0
        pp = fwd(Ap, Ws, Bs, DEPTH, L);
        set(h1a,'XData',1:t,'YData',max(Lh(1:t),1e-12));
        set(h3,'YData',pp);
        set(h4,'YData',pp - ep);
        if any(t == CKPT)
            ytrh = gen_batch(XTR, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND);
            yteh = gen_batch(XTE, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND);
            ck(end+1)    = t;
            ckTr(end+1)  = 100*mean(ytrh == Yt2(:));
            ckTe(end+1)  = 100*mean(yteh == Yte(:));
            ckLte(end+1) = heldout_loss(XTE, RULE, Vi, KMAX, TOKENS, ND, NV, Ws,Bs,DEPTH,L);
            set(h1b,'XData',ck,'YData',max(ckLte,1e-12));
            set(h2a,'XData',ck,'YData',ckTr);
            set(h2b,'XData',ck,'YData',ckTe);
        end
        drawnow;
    end
end

%% ---- results ------------------------------------------------------
yTR = gen_batch(XTR, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND);
yTE = gen_batch(XTE, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND);
aTR = 100*mean(yTR == Yt2(:));
aTE = 100*mean(yTE == Yte(:));

fprintf('L(theta*)                : %.4f\n', Lh(end));
fprintf('exact match, seen        : %6.1f %%\n', aTR);
fprintf('exact match, held out    : %6.1f %%\n', aTE);

if strcmp(TOKENS,'digit')
    DH = zeros(1,ND); DT = zeros(1,ND);
    for k = 1:ND
        p10 = 10^(ND-k);
        DH(k) = 100*mean(mod(floor(yTE/p10),10) == mod(floor(Yte(:)/p10),10));
        DT(k) = 100*mean(mod(floor(yTR/p10),10) == mod(floor(Yt2(:)/p10),10));
    end
    fprintf('\nper-token accuracy (position 1 = most significant)\n');
    fprintf('  seen     :'); fprintf(' %7.1f', DT); fprintf('\n');
    fprintf('  held out :'); fprintf(' %7.1f', DH); fprintf('\n');
end

bad = find(yTE ~= Yte(:));
if ~isempty(bad)
    fprintf('\nheld-out errors (first 10)\n');
    for j = bad(1:min(10,numel(bad)))'
        fprintf('  x = %-4d  yhat = %-6d  y = %-6d  delta = %+d\n', ...
                XTE(j), yTE(j), Yte(j), yTE(j)-Yte(j));
    end
end

%% ---- prompt loop ---------------------------------------------------
fprintf('\nenter x in 1..99, or 0 to stop\n');
figure('Color','w','Position',[60 60 1120 320]);
while true
    xq = input('  x = ');
    if isempty(xq) || xq == 0, break; end
    if xq < 1 || xq > 99 || xq ~= fix(xq), fprintf('  1..99\n'); continue; end

    yq = ruleval(xq, RULE);
    [yh, Psteps, toks] = gen_trace(xq, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND);
    if any(XTR == xq), tag = 'seen'; else, tag = 'held out'; end

    fprintf('  x = %d (%s)\n', xq, tag);
    for k = 1:ND
        [pk, ~] = max(Psteps(k,:));
        fprintf('    step %d : token %-6s  p = %.4f\n', k, V{toks(k)}, pk);
    end
    if yh == yq, vd = 'match'; else, vd = sprintf('delta %+d', yh-yq); end
    fprintf('    yhat = %d    y = %d    %s\n\n', yh, yq, vd);

    clf;
    for k = 1:ND
        ax = subplot(1,ND,k);
        bar(ax, 1:NV, Psteps(k,:), 'FaceColor', cA, 'EdgeColor','none');
        set(ax,'XTick',1:NV,'XTickLabel',V,'XTickLabelRotation',90);
        xlim(ax,[0.4 NV+0.6]); ylim(ax,[0 1]); grid(ax,'on'); box(ax,'on');
        xlabel(ax,'{\it v} \in {\it V}');
        if k == 1, ylabel(ax,'{\it P}({\it v} | ctx)'); end
        title(ax, sprintf('step %d', k));
    end
    drawnow;
end
fprintf('\n');

%% ===================================================================
%  FUNCTIONS
%  ===================================================================

function y = ruleval(x, RULE)
    x = x(:)';
    switch RULE
        case 'copy',    y = x;
        case 'reverse', y = mod(x,10)*10 + floor(x/10);
        case 'x+7',     y = x + 7;
        case '2x+1',    y = 2*x + 1;
        case '3x',      y = 3*x;
        case 'x^2',     y = x.^2;
        otherwise, error('unknown RULE');
    end
end

function [XTR, XTE] = split_x(XALL, SPLIT)
    switch SPLIT
        case 'random'
            pm = randperm(numel(XALL));
            XTR = sort(XALL(pm(1:80)));  XTE = sort(XALL(pm(81:end)));
        case 'range'
            XTR = XALL(XALL <= 69);      XTE = XALL(XALL >= 70);
        case 'parity'
            s = floor(XALL/10) + mod(XALL,10);
            XTR = XALL(mod(s,2)==0);     XTE = XALL(mod(s,2)==1);
        otherwise, error('unknown SPLIT');
    end
end

function nd = ndig_out(XALL, RULE, TOKENS)
    if strcmp(TOKENS,'word'), nd = 1; else
        nd = numel(sprintf('%d', max(ruleval(XALL,RULE))));
    end
end

function [V, Vi] = make_vocab(XALL, RULE, TOKENS)
    if strcmp(TOKENS,'digit')
        V = [arrayfun(@(k) sprintf('%d',k), 0:9, 'UniformOutput', false), {'=','<eos>','<pad>'}];
    else
        yv = ruleval(XALL,RULE);
        u  = unique([XALL(:); yv(:)])';
        V  = [arrayfun(@(k) sprintf('%d',k), u, 'UniformOutput', false), {'=','<eos>','<pad>'}];
    end
    Vi = containers.Map(V, 1:numel(V));
end

function Y = corrupt(XTR, RULE, NOISE)
    Y = ruleval(XTR, RULE);
    if NOISE <= 0, return; end
    m = rand(1,numel(XTR)) < NOISE;
    xs = XTR(:)';
    alt = xs + (2*(rand(1,numel(xs))>0.5) - 1);
    alt = min(max(alt,1),99);
    Y(m) = ruleval(alt(m), RULE);
end

function s = seq_of(x, y, Vi, TOKENS, ND)
    if strcmp(TOKENS,'digit')
        sx = sprintf('%02d', x);  sy = sprintf(['%0' num2str(ND) 'd'], y);
        s = zeros(1, 2+1+ND+1);
        for i=1:2,  s(i)     = Vi(sx(i)); end
        s(3) = Vi('=');
        for i=1:ND, s(3+i)   = Vi(sy(i)); end
        s(end) = Vi('<eos>');
    else
        s = [Vi(sprintf('%d',x)), Vi('='), Vi(sprintf('%d',y)), Vi('<eos>')];
    end
end

function c = pad_ctx(s, KMAX, Vi)
    s = s(max(1,numel(s)-KMAX+1):end);
    c = [repmat(Vi('<pad>'), 1, KMAX-numel(s)), s];
end

function [C, T] = examples(XTR, Ytr, Vi, KMAX, TOKENS, ND)
    C = []; T = [];
    if strcmp(TOKENS,'digit'), start = 4; else, start = 3; end
    for j = 1:numel(XTR)
        s = seq_of(XTR(j), Ytr(j), Vi, TOKENS, ND);
        for k = start:numel(s)
            C(end+1,:) = pad_ctx(s(1:k-1), KMAX, Vi); %#ok<AGROW>
            T(end+1,1) = s(k);                        %#ok<AGROW>
        end
    end
end

function A = encode(C, NV)
    [n, K] = size(C);  A = zeros(n, K*NV);
    for j = 1:K
        A(sub2ind([n K*NV], (1:n)', (j-1)*NV + C(:,j))) = 1;
    end
end

function P = fwd(A, Ws, Bs, DEPTH, L)
    H = A;
    for i = 1:DEPTH, H = tanh(H*Ws{i} + Bs{i}); end
    Z = H*Ws{L} + Bs{L};
    Zs = Z - max(Z,[],2);  E = exp(Zs);  P = E ./ sum(E,2);
end

function y = gen_batch(xs, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND)
    xs = xs(:); n = numel(xs);
    if n == 0, y = zeros(0,1); return; end
    S = zeros(n,0);
    for j = 1:n
        if strcmp(TOKENS,'digit')
            sx = sprintf('%02d', xs(j));
            S(j,1:3) = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
        else
            S(j,1:2) = [Vi(sprintf('%d',xs(j))), Vi('=')];
        end
    end
    out = zeros(n,ND);
    for k = 1:ND
        C = zeros(n,KMAX);
        for j = 1:n, C(j,:) = pad_ctx(S(j,:), KMAX, Vi); end
        P = fwd(encode(C,NV), Ws,Bs,DEPTH,L);
        [~, nx] = max(P,[],2);
        out(:,k) = nx;  S = [S, nx];
    end
    y = tok2num(out, V, TOKENS, ND);
end

function [y, Psteps, toks] = gen_trace(x, Ws,Bs,DEPTH,L, Vi,V,KMAX,NV,TOKENS,ND)
    if strcmp(TOKENS,'digit')
        sx = sprintf('%02d', x);  S = [Vi(sx(1)), Vi(sx(2)), Vi('=')];
    else
        S = [Vi(sprintf('%d',x)), Vi('=')];
    end
    Psteps = zeros(ND,NV);  toks = zeros(1,ND);
    for k = 1:ND
        P = fwd(encode(pad_ctx(S,KMAX,Vi), NV), Ws,Bs,DEPTH,L);
        Psteps(k,:) = P;
        [~, nx] = max(P);  toks(k) = nx;  S = [S, nx];
    end
    y = tok2num(toks, V, TOKENS, ND);
end

function y = tok2num(out, V, TOKENS, ND)
    n = size(out,1);  y = zeros(n,1);
    for j = 1:n
        if strcmp(TOKENS,'word')
            t = V{out(j,1)};  v = str2double(t);
            if isnan(v), v = -1; end
            y(j) = v;
        else
            v = 0;  ok = true;
            for k = 1:ND
                d = str2double(V{out(j,k)});
                if isnan(d), ok = false; break; end
                v = v*10 + d;
            end
            if ok, y(j) = v; else, y(j) = -1; end
        end
    end
end

function Lv = heldout_loss(XTE, RULE, Vi, KMAX, TOKENS, ND, NV, Ws,Bs,DEPTH,L)
    if isempty(XTE), Lv = nan; return; end
    [C,T] = examples(XTE, ruleval(XTE,RULE), Vi, KMAX, TOKENS, ND);
    P = fwd(encode(C,NV), Ws,Bs,DEPTH,L);
    m = numel(T);
    Lv = -sum(log(P(sub2ind([m NV],(1:m)',T(:))) + realmin))/m;
end
